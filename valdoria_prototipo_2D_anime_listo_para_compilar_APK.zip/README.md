# Prototipo 2 — A + C

# Prototipo Android — Valdoria

## Incluye
- Prototipo jugable en WebView y assets locales; el juego de demostración funciona sin internet.
- Controles de estrategia básicos y selección de casillas.
- Botones conceptuales para Wi-Fi Direct y Bluetooth.

## Muy importante
Este ZIP es el **proyecto fuente**, no un APK listo para instalar. Requiere Android Studio, JDK 17 y Android SDK para compilarlo. Los botones Wi-Fi Direct y Bluetooth solo muestran el estado del prototipo: la conexión multijugador real entre teléfonos no está implementada. Para que funcione, se necesita desarrollar la capa nativa de descubrimiento, emparejamiento, envío de mensajes, sincronización de turnos y pruebas en dispositivos reales.

## Compilar
1. Descomprime el ZIP.
2. Abre la carpeta del proyecto en Android Studio.
3. Espera la sincronización de Gradle e instala los componentes que solicite.
4. Selecciona Build > Build APK(s).
5. Busca `app/build/outputs/apk/debug/app-debug.apk`.

**Gráficos:** mapa 2D de casillas y estilo pixel-art con temática anime.
