REINO DE VALDORIA — PROTOTIPO 2D ANIME

Este archivo es el proyecto fuente, no el APK ya compilado.
El proyecto incluye una tarea de GitHub Actions para compilar el APK en la nube.

CÓMO OBTENER EL APK DESDE UN TELÉFONO:
1. Crea una cuenta o inicia sesión en GitHub.
2. Crea un repositorio nuevo y súbele el contenido de esta carpeta (no solo el ZIP).
3. En el repositorio abre la pestaña Actions.
4. Selecciona “Compilar APK de Valdoria” y pulsa “Run workflow”.
5. Cuando termine correctamente, abre la ejecución y descarga el artefacto “Valdoria-APK”.
6. Descomprime el artefacto y encontrarás app-debug.apk. Ábrelo en tu Android para instalarlo.

IMPORTANTE:
- El APK será una versión de prueba y puede requerir permitir la instalación desde esa fuente.
- El prototipo NO tiene multijugador real por Wi-Fi Direct/Bluetooth; esos controles son demostrativos.
- No está publicado en Google Play.
