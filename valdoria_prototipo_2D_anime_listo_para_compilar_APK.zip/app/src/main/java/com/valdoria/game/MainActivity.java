package com.valdoria.game;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.WebViewClient;
import android.graphics.Color;
public class MainActivity extends Activity {
 @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(Color.rgb(17,26,41));getWindow().setNavigationBarColor(Color.rgb(17,26,41));WebView w=new WebView(this);w.setBackgroundColor(Color.rgb(17,26,41));WebSettings s=w.getSettings();s.setJavaScriptEnabled(true);w.setWebViewClient(new WebViewClient());setContentView(w);w.loadUrl("file:///android_asset/index.html");}
}